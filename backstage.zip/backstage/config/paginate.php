<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018/11/16 0016
 * Time: 上午 11:00
 */

return [
	'type'     => \app\service\PaginateService::class,
	'var_page' => 'page',
];