<?php

//即盟网数据库
return [
	'join' =>[
		'type' => 'mysql',
		'hostname' => '127.0.0.1',
		'database' => 'joina',
		'username' => 'root',
		'password' => 'root',
		'hostport' => '3306',
		'charset' => 'utf8',
		'prefix' => 'on_',
		'debug' => '1',
		'datetime_format' => 'Y-m-d H:i:s',
	]
];