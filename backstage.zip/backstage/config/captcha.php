<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018/11/13 0013
 * Time: 上午 9:20
 */

return [
	// 验证码字体大小
	'fontSize' => 20,
	// 验证码位数
	'length'  => 4,
	// 关闭验证码杂点
	'useNoise' =>  false,
];