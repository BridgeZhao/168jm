<?php /*a:2:{s:68:"F:\php\phpstudy\PHPTutorial\WWW\backstage\views\admin\log\index.html";i:1552620293;s:70:"F:\php\phpstudy\PHPTutorial\WWW\backstage\views\admin\public\base.html";i:1553135219;}*/ ?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo config('admin.title'); ?></title>
    <link rel="shortcut icon" href="favicon.ico">
    <link href="/assets/css/bootstrap.min.css?v=3.3.6" rel="stylesheet">
    <link href="/assets/css/font-awesome.css?v=4.4.0" rel="stylesheet">
    <link href="/assets/css/animate.css" rel="stylesheet">
    <link href="/assets/css/style.css?v=4.1.0" rel="stylesheet">
    <link href="/assets/plugins/css/toastr/toastr.min.css" rel="stylesheet">
    <!-- 全局js -->
	<script src="/assets/js/jquery.min.js?v=2.1.4"></script>
	<script src="/assets/js/bootstrap.min.js?v=3.3.6"></script>
	<script src="/assets/plugins/js/toastr/toastr.min.js"></script>
	<script src="/assets/js/content.js?v=1.0.0"></script>
	<script src="/assets/plugins/js/layer/layer.js"></script>
    
    <style>
        .page-form-control {
            background-color: rgb(255, 255, 255);
            background-image: none;
            color: inherit;
            font-size: 1px;
            border-color: rgb(229, 230, 231);
            border-image: initial;
            border-radius: 1px;
            padding: 5px 12px;
        }
        .page-form-control-input {
            background-color: rgb(255, 255, 255);
            background-image: none;
            color: inherit;
            font-size: 1px;
            padding: 5px 5px 1px 12px;
            width: 10%;
        }
    </style>
</head>
<body class="gray-bg">
<div class="wrapper wrapper-content">
    <div class="ibox-title">首页 / 日志列表</div>
    <form role="form" class="form-inline">
    <div class="ibox-title">
            
<div class="form-group">
    <label for="name" class="sr-only">用户名</label>
    <input type="text" name="name" placeholder="请输入用户名" id="name" class="form-control" value="<?php echo htmlentities(app('request')->param('name')); ?>">
</div>
<?php echo searchButton(); ?>

    </div>
    <div class="row">
        <div class="col-sm-12">
            <div class="ibox float-e-margins">
                <div class="ibox-content">
                    
                    <div class="table-responsive">
                        <table class="table">
                            <thead>
                                 
<tr>
    <th>ID</th>
    <th>用户名</th>
    <th>操作</th>
    <th>模块</th>
    <th>控制器</th>
    <th>方法</th>
    <th>请求类型</th>
    <th>时间</th>
</tr>

                            </thead>
                            <tbody>
                                
<?php if(!$list->count()): ?>
<tr>
    <td colspan="7" class="text-center">没有数据</td>
</tr>
<?php else: foreach($list as $key => $log): ?>
<tr>
    <td><?php echo htmlentities($start + $key); ?></td>
    <td><?php echo htmlentities($log->user_name); ?></td>
    <td><?php echo htmlentities($log->option); ?></td>
    <td><?php echo htmlentities($log->module); ?></td>
    <td><?php echo htmlentities($log->controller); ?></td>
    <td><?php echo htmlentities($log->action); ?></td>
    <td><?php echo htmlentities($log->method); ?></td>
    <td><?php echo htmlentities($log->created_at); ?></td>
</tr>
<?php endforeach; ?>
<?php endif; ?>

                            </tbody>
                        </table>
                    </div>
                    
<?php echo $list->render(); ?>

                </div>
            </div>
        </div>
    </div>
    </form>
</div>


</body>
</html>
<script>
    $('.delete').click(function () {
        id = $(this).attr('data');
        url = $(this).attr('data-url')
        var index = layer.confirm('确认删除？', {
            btn: ['确认','取消'] //按钮
        }, function(){
            layer.close(index)
            $.post(url, {id:id}, function (response) {
                if (!response.code) {
                    warning(response.msg)
                } else {
                    success(response.msg)
                    setTimeout(function(){
                        window.location.href = response.url
                    }, response.wait * 1000);
                }
            })
        });
    })
    $('.hrefTo').click(function () {
        $('form').submit();
    })
    $('.limit').change(function () {
        $('input[name=page]').val(1)
        $('form').submit();
    })
</script>
