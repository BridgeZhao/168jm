<?php /*a:2:{s:79:"F:\php\phpstudy\PHPTutorial\WWW\backstage\views\admin\role\givePermissions.html";i:1552620293;s:70:"F:\php\phpstudy\PHPTutorial\WWW\backstage\views\admin\public\form.html";i:1552620293;}*/ ?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo config('admin.title'); ?></title>
    <link rel="shortcut icon" href="favicon.ico">
    <link href="/assets/css/bootstrap.min.css?v=3.3.6" rel="stylesheet">
    <link href="/assets/css/font-awesome.css?v=4.4.0" rel="stylesheet">
    <link href="/assets/plugins/css/iCheck/custom.css" rel="stylesheet">
    <link href="/assets/css/animate.css" rel="stylesheet">
    <link href="/assets/css/style.css?v=4.1.0" rel="stylesheet">
    <link href="/assets/plugins/css/toastr/toastr.min.css" rel="stylesheet">
    
<link rel="stylesheet" href="/assets/plugins/css/ztree/bootstrapStyle/bootstrapStyle.css" type="text/css">

</head>
<body class="gray-bg">
<div class="wrapper wrapper-content">
    <div class="ibox-title">首页 / 角色管理 / 权限分配</div>
    <div class="row">
        <div class="col-sm-12">
            <div class="ibox float-e-margins">
                <div class="ibox-content">
                    <form method="post" class="form-horizontal" action="">
                        
<ul id="tree" class="ztree text-center"></ul>

                        <div class="form-group">
                            <div class="col-sm-4 col-sm-offset-2">
                                <button class="btn btn-primary" type="submit">保存</button>
                                <span class="btn btn-white" onclick="history.back()">返回</span>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- 全局js -->
<script src="/assets/js/jquery.min.js?v=2.1.4"></script>
<script src="/assets/js/bootstrap.min.js?v=3.3.6"></script>
<!-- 自定义js -->
<script src="/assets/plugins/js/toastr/toastr.min.js"></script>
<script src="/assets/js/content.js?v=1.0.0"></script>
<script src="/assets/js/jquery.form.js"></script>
<!-- iCheck -->
<script src="/assets/plugins/js/iCheck/icheck.min.js"></script>
<script>
    $(document).ready(function () {
        $('.i-checks').iCheck({
            checkboxClass: 'icheckbox_square-green',
            radioClass: 'iradio_square-green',
        });
    });
    $('form').ajaxForm(function(response) {
        if (!response.code) {
            warning(response.msg)
        } else {
            success(response.msg)
            setTimeout(function(){
                window.location.href = response.url
            }, response.wait * 1000);
        }
    });
</script>

<script type="text/javascript" src="/assets/plugins/js/ztree/jquery.ztree.core.js"></script>
<script type="text/javascript" src="/assets/plugins/js/ztree/jquery.ztree.excheck.js"></script>
<script type="text/javascript" src="/assets/plugins/js/ztree/jquery.ztree.exedit.js"></script>
<script>
    let setting = {
        view: {},
        check: {enable: true},
        async : {
            enable : true,
            url : '<?php echo url("role/getPermissionsOfRole"); ?>',
            otherParam : {"role_id" : "<?php echo htmlentities($role_id); ?>"},
            type: "post"
        },
        data: {simpleData: {enable: true, pIdKey : "pid",}},
        callback:{
            onAsyncSuccess: zTreeOnAsyncSuccess,
            onCheck:onCheck
        }
    };
    let ids;
    $(document).ready(function(){
        $.fn.zTree.init($("#tree"), setting, null);
    });
    function zTreeOnAsyncSuccess(event, treeId, treeNode, msg) {
        ids = [];
        let treeObj=$.fn.zTree.getZTreeObj("tree");
        nodes = treeObj.getCheckedNodes(true);
        for(let i=0; i<nodes.length; i++){
            ids.push(nodes[i].id); //获取选中节点的值
        }
        console.log(ids)
    };
    function onCheck(e,treeId,treeNode){
        ids = [];
        let treeObj=$.fn.zTree.getZTreeObj("tree");
        nodes = treeObj.getCheckedNodes(true);
        for(let i=0; i<nodes.length; i++){
            ids.push(nodes[i].id); //获取选中节点的值
        }
        console.log(ids)
    }
    $(".btn-primary").click(function(){
        $.post("<?php echo url('role/givePermissions'); ?>", {role_id:"<?php echo htmlentities($role_id); ?>", permissions: ids}, function(response){
            if (!response.code ) {
                warning(response.msg); return false;
            }
            success(response.msg)
            setTimeout(function(){
                window.location.href = response.url
            }, response.wait * 1000);
        });
    })
</script>

</body>
</html>
