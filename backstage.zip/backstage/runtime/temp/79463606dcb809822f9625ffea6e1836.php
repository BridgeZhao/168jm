<?php /*a:2:{s:70:"F:\php\phpstudy\PHPTutorial\WWW\backstage\views\admin\leave\index.html";i:1555468796;s:70:"F:\php\phpstudy\PHPTutorial\WWW\backstage\views\admin\public\base.html";i:1553135219;}*/ ?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo config('admin.title'); ?></title>
    <link rel="shortcut icon" href="favicon.ico">
    <link href="/assets/css/bootstrap.min.css?v=3.3.6" rel="stylesheet">
    <link href="/assets/css/font-awesome.css?v=4.4.0" rel="stylesheet">
    <link href="/assets/css/animate.css" rel="stylesheet">
    <link href="/assets/css/style.css?v=4.1.0" rel="stylesheet">
    <link href="/assets/plugins/css/toastr/toastr.min.css" rel="stylesheet">
    <!-- 全局js -->
	<script src="/assets/js/jquery.min.js?v=2.1.4"></script>
	<script src="/assets/js/bootstrap.min.js?v=3.3.6"></script>
	<script src="/assets/plugins/js/toastr/toastr.min.js"></script>
	<script src="/assets/js/content.js?v=1.0.0"></script>
	<script src="/assets/plugins/js/layer/layer.js"></script>
    
    <style>
        .page-form-control {
            background-color: rgb(255, 255, 255);
            background-image: none;
            color: inherit;
            font-size: 1px;
            border-color: rgb(229, 230, 231);
            border-image: initial;
            border-radius: 1px;
            padding: 5px 12px;
        }
        .page-form-control-input {
            background-color: rgb(255, 255, 255);
            background-image: none;
            color: inherit;
            font-size: 1px;
            padding: 5px 5px 1px 12px;
            width: 10%;
        }
    </style>
</head>
<body class="gray-bg">
<div class="wrapper wrapper-content">
    <div class="ibox-title">首页 / 留言列表
<button class="btn btn-info btn-xs merge-leave" type="button"><i class="fa fa-paste"></i> 同步留言</button>
</div>
    <form role="form" class="form-inline">
    <div class="ibox-title">
            
<div class="form-group">
    <select name='l_type' class="form-control">
    	<option value='0'>--来源--</option>
    	<option value='1' <?php echo app('request')->param('l_type')==1?'selected = "selected"':''; ?>>录入</option>
    	<option value='2' <?php echo app('request')->param('l_type')==2?'selected = "selected"':''; ?>>留言</option>
    </select>
    <select name='type' class="form-control">
    	<option value='0'>--类别--</option>
    	<option value='1' <?php echo app('request')->param('l_type')==1?'selected = "selected"':''; ?>>项目</option>
    	<option value='2' <?php echo app('request')->param('l_type')==2?'selected = "selected"':''; ?>>资讯</option>
    </select>
    <select name='c_type' class="form-control">
    	<option value='0'>--平台--</option>
    	<option value='1' <?php echo app('request')->param('l_type')==1?'selected = "selected"':''; ?>>PC</option>
    	<option value='2' <?php echo app('request')->param('l_type')==2?'selected = "selected"':''; ?>>WAP</option>
    </select>
    <select name='author' class="form-control">
    	<option value='0'>--录入人--</option>
    	<option value='-1' <?php echo app('request')->param('author')==-1?'selected = "selected"':''; ?>>系统</option>
    	<?php foreach($userList as $key => $val): ?>
    	<option value='<?php echo htmlentities($val->id); ?>' <?php echo app('request')->param('author')==$val->id?'selected = "selected"':''; ?>><?php echo htmlentities($val->name); ?></option>
    	<?php endforeach; ?>
    </select>
    <input type="text" name="project_name" placeholder="请输入项目名称" id="project_name" class="form-control" value="<?php echo htmlentities(app('request')->param('project_name')); ?>">
    <select name='category_1' class='category_1 form-control'>
    	<option value='0'>--行业--</option>
    	<?php foreach($categoryList as $key => $val): ?>
    	<option value='<?php echo htmlentities($val->id); ?>' <?php echo app('request')->param('category_1')==$val->id?'selected = "selected"':''; ?>><?php echo htmlentities($val->title); ?></option>
    	<?php endforeach; ?>
    </select>
    <select name='category_2' class='category_2 form-control'>
    	<option value='0'>--小行业--</option>
    	<?php foreach($categoryItemList as $key => $val): ?>
    	<option value='<?php echo htmlentities($val->id); ?>' <?php echo app('request')->param('category_2')==$val->id?'selected = "selected"':''; ?>><?php echo htmlentities($val->title); ?></option>
    	<?php endforeach; ?>
    </select>
    <input type='text' name='start_time' class='form-control start_time' value='<?php echo htmlentities(app('request')->param('start_time')); ?>' placeholder='开始时间'>
    <input type='text' name='end_time' class='form-control end_time' value='<?php echo htmlentities(app('request')->param('end_time')); ?>' placeholder='结束时间'>
    <input type="text" name="ip_site" placeholder="请输入地区名称" id="ip_site" class="form-control" value="<?php echo htmlentities(app('request')->param('ip_site')); ?>">
    <input type="text" name="content" placeholder="请输入内容" id="ip_site" class="form-control" value="<?php echo htmlentities(app('request')->param('content')); ?>">
</div>
<?php echo searchButton(); ?>

    </div>
    <div class="row">
        <div class="col-sm-12">
            <div class="ibox float-e-margins">
                <div class="ibox-content">
                    
                    <div class="table-responsive">
                        <table class="table">
                            <thead>
                                 
<tr>
    <th>ID</th>
    <th>项目名称</th>
    <th>来源</th>
    <th>所属行业</th>
    <th>姓名</th>
    <th>电话</th>
    <th>性别</th>
    <th>所在地区</th>
    <th>时间</th>
    <th>留言内容</th>
    <th>录入</th>
    <th>分配</th>
    <th>操作</th>
</tr>

                            </thead>
                            <tbody>
                                
<?php if(!$list->count()): ?>
<tr>
    <td colspan="7" class="text-center">没有数据</td>
</tr>
<?php else: foreach($list as $key => $val): ?>
<tr>
    <td><?php echo htmlentities($val->id); ?></td>
    <td><?php echo htmlentities($val->project_name); ?></td>
    <td><?php echo $val->c_type==1 ? 'PC' : 'WAP'; ?>/<?php echo $val->type==1 ? '项目' : '资讯'; ?></td>
    <td><?php echo $val->category_1!=0 ? htmlentities($categoryAll[$val->category_1]) : ''; ?>-<?php echo $val->category_2!=0 ? htmlentities($categoryAll[$val->category_2]) : ''; ?></td>
    <td><?php echo htmlentities($val->name); ?></td>
    <td><?php echo htmlentities($val->tel); ?></td>
    <td><?php echo $val->sex==1 || $val->sex==0 ? '男' : '女'; ?></td>
    <td><?php echo htmlentities($val->ip_site); ?></td>
    <td><?php echo htmlentities($val->add_time); ?></td>
    <td><?php echo htmlentities(mb_substr($val['content'],0,15,'utf-8')); ?></td>
    <td><?php echo $val->author==0 || !isset($userList[$val->author]) ? '系统' : htmlentities($userList[$val->author]['name']); ?></td>
    <td><span class='distribution' data-toggle="modal" data-target="#userModal" data-id='<?php echo htmlentities($val->id); ?>' data-project-name='<?php echo htmlentities($val->project_name); ?>' style='cursor:pointer;'>选取</span></td>
    <td data-id='<?php echo htmlentities($val->id); ?>'>
	    <!-- span class='leave-edit'><a href="<?php echo url('leave/edit', ['id' => $val->id ]); ?>">编辑</a></span> | 
	    <span class='leave-del'><a href="<?php echo url('leave/delete', ['id' => $val->id ]); ?>">删除</a></span-->
	    <?php echo editButton(url('leave/edit', ['id' => $val->id ])); ?> | 
	    <?php echo deleteButton(url('leave/delete'), $val->id); ?>
    </td>
</tr>
<div class="modal fade" id="userModal" tabindex="-1" role="dialog" aria-labelledby="userModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                <h4 class="modal-title" id="myModalLabel"></h4>
            </div>
            <div class="modal-body">
            	<div class='choose-user-top'>
	            	<span class='choose-text'>客户账号选择</span>
	            	<input type="text" class="form-control keyword" name="keyword" value='' placeholder="搜索客户名称">
	            	<!-- button class='user-search-btn'>查询</button-->
	            	<input type='button' value='查询' class='user-search-btn' data-l-id=''>
            	</div>
            	<div class='user-list-title'>
            		<div>Uid</div>
            		<div>用户名</div>
            		<div>操作</div>
            	</div>
            	<div class='user-list-all'>
            	
            	</div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-default" data-dismiss="modal">关闭</button>
            </div>
        </div><!-- /.modal-content -->
    </div><!-- /.modal -->
</div>
<?php endforeach; ?>
<?php endif; ?>

                            </tbody>
                        </table>
                    </div>
                    
<?php echo $list->render(); ?>
<script type="text/javascript" src="/assets/layui/layui.js"></script>
<link rel="stylesheet" type="text/css" href="/assets/layui/css/layui.css" media="all">
<script type="text/javascript">
var category_2 = <?php echo htmlentities($params['category_2']); ?>;
if (category_2 == 0) {
	$('.category_2').hide();
}
$('.category_1').change(function(){
	$('.category_2').show();
	$.ajax({
        type : "post",
        url : "/admin/category/getList",
        data : {
            "pid" : $(".category_1").val(),
        },
        success : function(data) {
        	$('.category_2 > option').remove();
        	var de_html = "<option value='0'>--小行业--</option>";
        	$(de_html).appendTo($('.category_2'));
        	$(data).each(function(i, v) {
                var html = '<option value="' + v.id + '">' + v.title + '</option>';
                
                $(html).appendTo($('.category_2'));
            });
        }
    });
})
$('.leave-del').click(function(){
	var id= $(this).parent().attr('data-id');
	$.ajax({
        type : "post",
        url : "/admin/leave/delete",
        data : {
            "id" : id,
        },
        success : function(data) {
        	
        }
    });
	
});
$('.user-search-btn').click(function(){
	var keyword = $('.keyword').val();
	var id = $(this).attr('data-l-id');
	$.ajax({
        type : "post",
        url : "/admin/leave/getDistributionUser",
        data : {
        	'id':id,
            "name" : keyword,
        },
        success : function(data) {
        	var html = '';
        	var list = data.data;
        	for(var i=0;i<list.length;i++) {
        		var status = list[i]['status']==0 || list[i]['status'] == null?'未分配':'已分配';
        		var status_id = list[i]['status'];
        		var state = 0;
        		if (list[i]['status'] == null) {
        			status_id = 0;
        		}
        		state = status_id==1?0:1;
        		html += "<div class='user-list'>";
        		html += "	<div>"+list[i]['id']+"</div>";
        		html += "	<div>"+list[i]['name']+"</div>";
        		html += "	<div class='fp' data-user-id='"+list[i]['id']+"' data-l-id='"+id+"' data-status='"+state+"'>"+status+"</div>";
        		html += "</div>";
        	}
        	$('.user-list').remove()
        	$('.user-list-all').append(html)
        }
    });
})
$('.distribution').click(function(){
	var project_name = $(this).attr('data-project-name');
	$('#myModalLabel').html(project_name + '留言分配');
	var keyword = $('.keyword').val();
	var id = $(this).attr('data-id');
	$('.user-search-btn').attr('data-l-id', id);
	$.ajax({
        type : "post",
        url : "/admin/leave/getDistributionUser",
        data : {
        	'id':id,
            //"name" : keyword,
        },
        success : function(data) {
        	var html = '';
        	var list = data.data;
        	for(var i=0;i<list.length;i++) {
        		//console.log(list[i]['id']);return false;
        		var status = list[i]['status']==0 || list[i]['status'] == null?'未分配':'已分配';
        		var status_id = list[i]['status'];
        		var state = 0;
        		if (list[i]['status'] == null) {
        			status_id = 0;
        		}
        		state = status_id==1?0:1;
        		html += "<div class='user-list'>";
        		html += "	<div>"+list[i]['id']+"</div>";
        		html += "	<div>"+list[i]['name']+"</div>";
        		html += "	<div class='fp' data-user-id='"+list[i]['id']+"' data-l-id='"+id+"' data-status='"+state+"'>"+status+"</div>";
        		html += "</div>";
        	}
        	$('.user-list').remove()
        	$('.user-list-all').append(html)
        }
    });
})
$('.user-list-all').on('click','.fp', function(){
	var _this = this;
	var user_id = $(this).attr('data-user-id');
	var l_id = $(this).attr('data-l-id');
	var status = $(this).attr('data-status');
	$.ajax({
        type : "post",
        url : "/admin/leave/distribution",
        data : {
        	'user_id':user_id,
            "l_id" : l_id,
            'status':status,
        },
        success : function(data) {
        	if (data.code == 0) {
        		var status_name = status==1?'已分配':'未分配';
        		var state = status == 1?0:1;
        		$(_this).html(status_name);
        		$(_this).attr('data-status',state);
        		//console.log($(this).html());
        	}
        }
    });
});
$('.merge-leave').click(function(){
	$.ajax({
        type : "post",
        url : "/admin/leave/mergeLeave",
        data : {},
        success : function(data) {
        	alert('同步完成');
        }
    });
});
	layui.use('laydate', function(){
        var laydate = layui.laydate;
        laydate.render({
            elem: '.start_time'
        });
    });
	layui.use('laydate', function(){
	    var laydate = layui.laydate;
	    laydate.render({
	        elem: '.end_time'
	    });
	});
</script>


                </div>
            </div>
        </div>
    </div>
    </form>
</div>


</body>
</html>
<script>
    $('.delete').click(function () {
        id = $(this).attr('data');
        url = $(this).attr('data-url')
        var index = layer.confirm('确认删除？', {
            btn: ['确认','取消'] //按钮
        }, function(){
            layer.close(index)
            $.post(url, {id:id}, function (response) {
                if (!response.code) {
                    warning(response.msg)
                } else {
                    success(response.msg)
                    setTimeout(function(){
                        window.location.href = response.url
                    }, response.wait * 1000);
                }
            })
        });
    })
    $('.hrefTo').click(function () {
        $('form').submit();
    })
    $('.limit').change(function () {
        $('input[name=page]').val(1)
        $('form').submit();
    })
</script>
