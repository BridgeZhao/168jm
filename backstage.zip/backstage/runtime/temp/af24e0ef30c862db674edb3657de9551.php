<?php /*a:2:{s:74:"F:\php\phpstudy\PHPTutorial\WWW\backstage\views\admin\leave\add_entry.html";i:1554890953;s:70:"F:\php\phpstudy\PHPTutorial\WWW\backstage\views\admin\public\form.html";i:1552620293;}*/ ?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo config('admin.title'); ?></title>
    <link rel="shortcut icon" href="favicon.ico">
    <link href="/assets/css/bootstrap.min.css?v=3.3.6" rel="stylesheet">
    <link href="/assets/css/font-awesome.css?v=4.4.0" rel="stylesheet">
    <link href="/assets/plugins/css/iCheck/custom.css" rel="stylesheet">
    <link href="/assets/css/animate.css" rel="stylesheet">
    <link href="/assets/css/style.css?v=4.1.0" rel="stylesheet">
    <link href="/assets/plugins/css/toastr/toastr.min.css" rel="stylesheet">
    
</head>
<body class="gray-bg">
<div class="wrapper wrapper-content">
    <div class="ibox-title">首页 / 用户管理 / 创建用户</div>
    <div class="row">
        <div class="col-sm-12">
            <div class="ibox float-e-margins">
                <div class="ibox-content">
                    <form method="post" class="form-horizontal" action="<?php echo htmlentities($url); ?>">
                        
    <div class="form-group">
        <label class="col-sm-2 control-label">姓名</label>
        <div class="col-sm-4">
            <input type="text" class="form-control" name="name" value='<?php echo !empty($info->name)?$info->name:"";?>' required>
        </div>
    </div>
    <div class="form-group">
        <label class="col-sm-2 control-label">电话号码</label>
        <div class="col-sm-4">
            <input type="tel" class="form-control" name="tel" required value='<?php echo !empty($info->tel)?$info->tel:"";?>'>
        </div>
    </div>
    <div class="form-group">
        <label class="col-sm-2 control-label">所在地区</label>
        <div class="col-sm-4">
            <input type="text" class="form-control" name="ip_site" value='<?php echo !empty($info->ip_site)?$info->ip_site:"";?>'>
        </div>
    </div>
    <div class="form-group">
        <label class="col-sm-2 control-label">来源</label>
        <div class="col-sm-4 radio i-checks">
	        <label><input type="radio" <?php if(!empty($info->c_type) && $info->c_type == 1): ?>checked<?php endif; ?> value="1" name="c_type"> <i></i>PC</label>
	        <label><input type="radio" <?php if(!empty($info->c_type) && $info->c_type == 2): ?>checked<?php endif; ?> value="2" name="c_type"><i></i>wap</label>
	    </div>
    </div>
    <div class="form-group">
        <label class="col-sm-2 control-label">性别</label>
        <div class="col-sm-4 radio i-checks">
	        <label><input type="radio" <?php if(!empty($info->sex) && $info->sex == 1): ?>checked<?php endif; ?> value="1" name="sex"> <i></i>男</label>
	        <label><input type="radio" <?php if(!empty($info->sex) && $info->sex == 2): ?>checked<?php endif; ?> value="2" name="sex"><i></i>女</label>
	    </div>
    </div>
    <div class="form-group">
        <label class="col-sm-2 control-label">项目名称</label>
        <div class="col-sm-4">
            <input type="text" class="form-control" name="project_name" value='<?php echo !empty($info->project_name)?$info->project_name:"";?>'>
        </div>
    </div>
    <div class="form-group">
        <label class="col-sm-2 control-label">投资费用</label>
        <div class="col-sm-4">
            <input type="text" class="form-control" name="invest_money" value='<?php echo !empty($info->invest_money)?$info->invest_money:"";?>'><span style='float:right;margin-top:-24px;'>万元</span>
        </div>
    </div>
    <div class="form-group">
        <label class="col-sm-2 control-label">留言内容</label>
        <div class="col-sm-4">
            <textarea type="text" class="" name="content" style='height:80px;width:600px;border: 1px solid #e5e6e7;'><?php echo !empty($info->content)?$info->content:"";?></textarea>
        </div>
    </div>
    <input type="hidden" name="id" value="<?php echo !empty($info->id)?$info->id:"";?>">

                        <div class="form-group">
                            <div class="col-sm-4 col-sm-offset-2">
                                <button class="btn btn-primary" type="submit">保存</button>
                                <span class="btn btn-white" onclick="history.back()">返回</span>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- 全局js -->
<script src="/assets/js/jquery.min.js?v=2.1.4"></script>
<script src="/assets/js/bootstrap.min.js?v=3.3.6"></script>
<!-- 自定义js -->
<script src="/assets/plugins/js/toastr/toastr.min.js"></script>
<script src="/assets/js/content.js?v=1.0.0"></script>
<script src="/assets/js/jquery.form.js"></script>
<!-- iCheck -->
<script src="/assets/plugins/js/iCheck/icheck.min.js"></script>
<script>
    $(document).ready(function () {
        $('.i-checks').iCheck({
            checkboxClass: 'icheckbox_square-green',
            radioClass: 'iradio_square-green',
        });
    });
    $('form').ajaxForm(function(response) {
        if (!response.code) {
            warning(response.msg)
        } else {
            success(response.msg)
            setTimeout(function(){
                window.location.href = response.url
            }, response.wait * 1000);
        }
    });
</script>

</body>
</html>
