<?php /*a:2:{s:68:"F:\php\phpstudy\PHPTutorial\WWW\backstage\views\admin\user\edit.html";i:1552620293;s:70:"F:\php\phpstudy\PHPTutorial\WWW\backstage\views\admin\public\form.html";i:1552620293;}*/ ?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo config('admin.title'); ?></title>
    <link rel="shortcut icon" href="favicon.ico">
    <link href="/assets/css/bootstrap.min.css?v=3.3.6" rel="stylesheet">
    <link href="/assets/css/font-awesome.css?v=4.4.0" rel="stylesheet">
    <link href="/assets/plugins/css/iCheck/custom.css" rel="stylesheet">
    <link href="/assets/css/animate.css" rel="stylesheet">
    <link href="/assets/css/style.css?v=4.1.0" rel="stylesheet">
    <link href="/assets/plugins/css/toastr/toastr.min.css" rel="stylesheet">
    
</head>
<body class="gray-bg">
<div class="wrapper wrapper-content">
    <div class="ibox-title">首页 / 用户管理 / 编辑用户</div>
    <div class="row">
        <div class="col-sm-12">
            <div class="ibox float-e-margins">
                <div class="ibox-content">
                    <form method="post" class="form-horizontal" action="<?php echo url('user/edit'); ?>">
                        
    <div class="form-group">
        <label class="col-sm-2 control-label">用户名</label>
        <div class="col-sm-4">
            <input type="text" class="form-control" name="name" value="<?php echo htmlentities($user->name); ?>">
        </div>
    </div>
    <div class="form-group">
        <label class="col-sm-2 control-label">邮箱</label>
        <div class="col-sm-4">
            <input type="email" class="form-control" name="email" value="<?php echo htmlentities($user->email); ?>">
        </div>
    </div>
    <div class="form-group">
        <label class="col-sm-2 control-label">密码</label>
        <div class="col-sm-4">
            <input type="password" class="form-control" name="password">
        </div>
    </div>
    <div class="form-group">
        <label class="col-sm-2 control-label">确认密码</label>
        <div class="col-sm-4">
            <input type="password" class="form-control" name="password_confirm">
        </div>
    </div>
    <div class="form-group">
        <label class="col-sm-2 control-label">角色分配</label>
        <div class="col-sm-4 checkbox i-checks">
            <?php foreach($roles as $role): ?>
                <label><input type="checkbox" value="<?php echo htmlentities($role->id); ?>" name="roles[]" <?php if($role->checked): ?>checked<?php endif; ?>><i></i><?php echo htmlentities($role->name); ?></label>
            <?php endforeach; ?>
        </div>
    </div>
    <input type="hidden" name="id" value="<?php echo htmlentities($user->id); ?>">

                        <div class="form-group">
                            <div class="col-sm-4 col-sm-offset-2">
                                <button class="btn btn-primary" type="submit">保存</button>
                                <span class="btn btn-white" onclick="history.back()">返回</span>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- 全局js -->
<script src="/assets/js/jquery.min.js?v=2.1.4"></script>
<script src="/assets/js/bootstrap.min.js?v=3.3.6"></script>
<!-- 自定义js -->
<script src="/assets/plugins/js/toastr/toastr.min.js"></script>
<script src="/assets/js/content.js?v=1.0.0"></script>
<script src="/assets/js/jquery.form.js"></script>
<!-- iCheck -->
<script src="/assets/plugins/js/iCheck/icheck.min.js"></script>
<script>
    $(document).ready(function () {
        $('.i-checks').iCheck({
            checkboxClass: 'icheckbox_square-green',
            radioClass: 'iradio_square-green',
        });
    });
    $('form').ajaxForm(function(response) {
        if (!response.code) {
            warning(response.msg)
        } else {
            success(response.msg)
            setTimeout(function(){
                window.location.href = response.url
            }, response.wait * 1000);
        }
    });
</script>

</body>
</html>
