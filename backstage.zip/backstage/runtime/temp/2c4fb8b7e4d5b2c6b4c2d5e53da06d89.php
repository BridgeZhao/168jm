<?php /*a:2:{s:76:"F:\php\phpstudy\PHPTutorial\WWW\backstage\views\admin\permission\create.html";i:1552620293;s:70:"F:\php\phpstudy\PHPTutorial\WWW\backstage\views\admin\public\form.html";i:1552620293;}*/ ?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo config('admin.title'); ?></title>
    <link rel="shortcut icon" href="favicon.ico">
    <link href="/assets/css/bootstrap.min.css?v=3.3.6" rel="stylesheet">
    <link href="/assets/css/font-awesome.css?v=4.4.0" rel="stylesheet">
    <link href="/assets/plugins/css/iCheck/custom.css" rel="stylesheet">
    <link href="/assets/css/animate.css" rel="stylesheet">
    <link href="/assets/css/style.css?v=4.1.0" rel="stylesheet">
    <link href="/assets/plugins/css/toastr/toastr.min.css" rel="stylesheet">
    
</head>
<body class="gray-bg">
<div class="wrapper wrapper-content">
    <div class="ibox-title">首页 / 菜单管理 / 创建菜单</div>
    <div class="row">
        <div class="col-sm-12">
            <div class="ibox float-e-margins">
                <div class="ibox-content">
                    <form method="post" class="form-horizontal" action="<?php echo url('permission/create'); ?>">
                        
<?php if(!$permissionId): ?>
<div class="form-group">
    <label class="col-sm-2 control-label">选择父级菜单</label>
    <div class="col-sm-4">
        <select class="form-control m-b" name="pid">
            <option value="0">--请选择父级菜单--</option>
            <?php foreach($permissions as $permission): ?>
            <option value="<?php echo htmlentities($permission->id); ?>"><?php echo str_repeat('&nbsp;&nbsp;', $permission->level); ?> <?php echo htmlentities($permission->name); ?></option>
            <?php endforeach; ?>
        </select>
    </div>
</div>
<?php else: ?>
<input type="hidden" name="pid" value="<?php echo htmlentities($permissionId); ?>">
<?php endif; ?>
<div class="form-group">
    <label class="col-sm-2 control-label">菜单名称</label>
    <div class="col-sm-4">
        <input type="text" class="form-control" name="name" required>
    </div>
</div>
<div class="form-group">
    <label class="col-sm-2 control-label">菜单图标</label>
    <div class="col-sm-4">
        <input type="text" class="form-control" name="icon" placeholder="fa fa-home">
        <div><a href="http://fontawesome.dashgame.com/" target="_blank">请跳转至图标库选择</a> 例如: fa fa-home</div>
    </div>
</div>
<div class="form-group">
    <label class="col-sm-2 control-label">模块</label>
    <div class="col-sm-4">
        <input type="text" class="form-control" name="module" required>
    </div>
</div>
<div class="form-group">
    <label class="col-sm-2 control-label">控制器</label>
    <div class="col-sm-4">
        <input type="text" class="form-control" name="controller" required>
    </div>
</div>
<div class="form-group">
    <label class="col-sm-2 control-label">方法</label>
    <div class="col-sm-4">
        <input type="text" class="form-control" name="action" required>
    </div>
</div>
<div class="form-group">
    <label class="col-sm-2 control-label">展示</label>
    <div class="col-sm-4 radio i-checks">
        <label><input type="radio" checked value="1" name="is_show"> <i></i>是</label>
        <label><input type="radio" value="2" name="is_show"><i></i>否</label>
    </div>
</div>

                        <div class="form-group">
                            <div class="col-sm-4 col-sm-offset-2">
                                <button class="btn btn-primary" type="submit">保存</button>
                                <span class="btn btn-white" onclick="history.back()">返回</span>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- 全局js -->
<script src="/assets/js/jquery.min.js?v=2.1.4"></script>
<script src="/assets/js/bootstrap.min.js?v=3.3.6"></script>
<!-- 自定义js -->
<script src="/assets/plugins/js/toastr/toastr.min.js"></script>
<script src="/assets/js/content.js?v=1.0.0"></script>
<script src="/assets/js/jquery.form.js"></script>
<!-- iCheck -->
<script src="/assets/plugins/js/iCheck/icheck.min.js"></script>
<script>
    $(document).ready(function () {
        $('.i-checks').iCheck({
            checkboxClass: 'icheckbox_square-green',
            radioClass: 'iradio_square-green',
        });
    });
    $('form').ajaxForm(function(response) {
        if (!response.code) {
            warning(response.msg)
        } else {
            success(response.msg)
            setTimeout(function(){
                window.location.href = response.url
            }, response.wait * 1000);
        }
    });
</script>

</body>
</html>
