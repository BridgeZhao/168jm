<?php
namespace app\model;

class CategoryModel extends BaseModel
{
	protected $name = 'category';
	/**
	 * 获取第一行业
	 */
	public function getCategory($pid = 0)
	{
		$where = ['pid' => $pid];
		$list = $this->where($where)->select();
		return $list;
	}
	public function getAllCategory()
	{
		$list = $this->field('id,title')->select();
		$data = [];
		foreach ($list as $val) {
			$data[$val['id']] = $val['title'];
		}
		return $data;
	}
	public function getCategoryList()
	{
		$list = $this->field('id,title,pid')->select();
		return $list;
	}

}