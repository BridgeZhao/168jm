<?php
namespace app\model;

class distributionModel extends BaseModel{
	protected $name = 'distribution';
	
	/**
	 * 获取分配用户列表
	 * @param unknown $l_id
	 * @return unknown
	 */
	public function getDistributionUser($l_id, $keyword = '')
    {
    	$where = array();
    	if ($keyword) {
    		$where = array(array('u.name', 'like', '%'.$keyword.'%'));
    	}
    	$list = $this->alias('d')
	    	->field('u.id,u.`name`,d.status')
	    	->join('cms_users u','u.id=d.user_id and d.l_id = '.$l_id,'right')
	    	->where($where)
	    	->select();
    	return $list;
    }
    
    /**
     * 获取分配信息
     * @param  $where 搜索条件
     * @return unknown
     */
    public function getInfo($where)
    {
    	$info = $this->where($where)->find();
    	return $info;
    }
    
    /**
     * 分配
     * @param integer $l_id	留言id
     * @param integer $user_id	用户id
     * @param integer $status	分配状态	1分配0取消分配
     * @return multitype:number multitype:string
     */
    public function distribution($l_id, $user_id, $status = 1)
    {
    	$userModel = new UserModel();
    	$user_info = $userModel->getUserInfo($user_id);
    	if (empty($user_info)) {
    		return array('code' => 10001, 'data' => array('msg' => '客户信息不存在'));
    	}
    	$dis_where['l_id'] = $l_id;
    	$dis_where['user_id'] = $user_id;
    	$distributionInfo = $this->getInfo($dis_where);
    	if (empty($distributionInfo)) {
    		$data = array(
    			'user_id' => $user_id,
    			'l_id' => $l_id,
    			'type' => 0,
    			'add_time' => time(),
    			'status' => $status,
    		);
    		$res = $this->save($data);
    	} else {
    		$data['update_time'] = time();
    		$data['status'] = $status;
    		if ($status == 1) {
    			$data['add_time'] = time();
    		}
    		$where = array(
    			'id' => $distributionInfo['id'],
    		);
    		$res = $this->where($where)->update($data);
    	}
    	if ($res !== false) {
    		return array('code' => 0, 'data' => array('msg' => '分配成功'));
    	} else {
    		return array('code' => 10002, 'data' => array('msg' => '分配失败'));
    	}
    }
    
    /**
     * 客户数据列表
     * @param integer $user_id
     * @return unknown
     */
    public function customerList($user_id, $params, $limit = self::LIMIT)
    {
    	$where = array();
    	$where[] = array('d.user_id', '=', $user_id);
    	$where[] = array('d.status', '=', 1);
    	if (!empty($params['project_name'])) {
    		$where[] = array('lw.project_name', 'like', '%'.$params['project_name'].'%');
    	}
    	if (!empty($params['start_time']) && !empty($params['end_time'])) {
    		/* if ($params['start_time'] == $params['end_time']) {
    			$params['end_time'] = $params['start_time'] .' 23:59:59';
    		} */
    		$where[] = array('lw.add_time', 'between', [$params['start_time'], $params['end_time']]);
    	} elseif (!empty($params['start_time']) && empty($params['end_time'])) {
    		$where[] = array('lw.add_time', '>=', $params['start_time']);
    	} elseif (empty($params['start_time']) && !empty($params['end_time'])) {
    		$where[] = array('lw.add_time', '<=', $params['end_time']);
    	}
    	if (!empty($params['ip_site'])) {
    		$where[] = array('lw.ip_site', 'like', '%'.$params['ip_site'].'%');
    	}
    	if (!empty($params['content'])) {
    		$where[] = array('lw.content', 'like', '%'.$params['content'].'%');
    	}
    	if (!empty($params['id']) && is_array($params['id'])) {
    		$where[] = array('lw.id', 'in', $params['id']);
    	}
    	
    	$model = $this->alias('d')
	    	->field('lw.id,lw.project_name,lw.name,lw.tel,lw.sex,lw.ip_site,lw.add_time,lw.content,d.id did,d.type,d.is_export,d.export_time,d.user_id,d.d_content,d.add_time d_add_time')
	    	->join('cms_leave_word lw','lw.id=d.l_id')
	    	->where($where)
    		->order('d.id desc');
    	if (!empty($limit)) {
    		$list = $model->paginate($limit, false, ['query' => request()->param()]);
    	} else {
    		$list = $model->select();
    	}
    	return $list;
    }
    
    
    public function feedbackList($params, $limit = self::LIMIT)
    {
    	$where = array();
    	$where[] = array('d.status', '=', 1);
    	if (!empty($params['project_name'])) {
    		$where[] = array('lw.project_name', 'like', '%'.$params['project_name'].'%');
    	}
    	if (!empty($params['start_time']) && !empty($params['end_time'])) {
    		/* if ($params['start_time'] == $params['end_time']) {
    			$params['end_time'] = $params['start_time'] .' 23:59:59';
    		} */
    		$where[] = array('lw.add_time', 'between', [$params['start_time'], $params['end_time']]);
    	} elseif (!empty($params['start_time']) && empty($params['end_time'])) {
    		$where[] = array('lw.add_time', '>=', $params['start_time']);
    	} elseif (empty($params['start_time']) && !empty($params['end_time'])) {
    		$where[] = array('lw.add_time', '<=', $params['end_time']);
    	}
    	if (!empty($params['user_name'])) {
    		$where[] = array('u.name', 'like', '%'.$params['user_name'].'%');
    	}
    	 
    	$model = $this->alias('d')
	    	->field('lw.id,lw.project_name,lw.name,lw.tel,lw.sex,lw.ip_site,lw.add_time,lw.content,d.id did,d.type,d.is_export,d.export_time,d.user_id,u.name user_name,d.d_content')
	    	->join('cms_leave_word lw','lw.id=d.l_id', 'left')
	    	->join('cms_users u', 'u.id=d.user_id', 'left')
	    	->where($where);
    	if (!empty($limit)) {
    		$list = $model->paginate($limit, false, ['query' => request()->param()]);
    	} else {
    		$list = $model->select();
    	}
    	return $list;
    }
    
    public function feedback($l_id, $d_id, $type = 0, $content = '')
    {
    	$where['id'] = $d_id;
    	$where['status'] = 1;
    	$where['l_id'] = $l_id;
    	$info = $this->getInfo($where);
    	if (empty($info)) {
    		return array('code' => 10001, 'data' => array('msg' => '数据不存在'));
    	}
    	if ($info['add_time']+86400 < time()) {
    		return array('code' => 10003, 'data' => array('msg' => '反馈无效，请在分配后24小时内反馈!'));
    	}
    	$data['id'] = $d_id;
    	if (!empty($type)) {
    		$data['type'] = $type;
    	}
    	if (!empty($content)) {
    		$data['d_content'] = $content;
    	}
    	$data['update_time'] = time();
    	//p($data);exit;
    	$res = $this->update($data);
    	if ($res !== false) {
    		return array('code' => 0, 'data' => array('msg' => '反馈成功'));
    	}
    	return array('code' => 10002, 'data' => array('msg' => '反馈失败'));
    }
    
    /**
     *处理Excel导出
     *@param $datas array 设置表格数据
     *@param $titlename string 设置head
     *@param $title string 设置表头
     */
    function excelData($datas,$titlename,$title,$filename){
    	$str = "<html xmlns:o=\"urn:schemas-microsoft-com:office:office\"\r\nxmlns:x=\"urn:schemas-microsoft-com:office:excel\"\r\nxmlns=\"http://www.w3.org/TR/REC-html40\">\r\n<head>\r\n<meta http-equiv=Content-Type content=\"text/html; charset=utf-8\">\r\n</head>\r\n<body>";
    	//$str .="<table border=1><head>".$title."</head>";
    	$str .= $titlename;
    	foreach ($datas as $key=> $rt )
    	{
    		$str .= "<tr>";
    		foreach ( $rt as $k => $v )
    		{
    			$str .= "<td>{$v}</td>";
    		}
    		$str .= "</tr>\n";
    	}
    	$str .= "</table></body></html>";
    	header( "Content-Type: application/vnd.ms-excel; name='excel'" );
    	header( "Content-type: application/octet-stream" );
    	header( "Content-Disposition: attachment; filename=".$filename );
    	header( "Cache-Control: must-revalidate, post-check=0, pre-check=0" );
    	header( "Pragma: no-cache" );
    	header( "Expires: 0" );
    	exit( $str );
    }
}
