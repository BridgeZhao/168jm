<?php

namespace app\model;

use think\permissions\traits\hasRoles;

class MergeLeaveModel extends BaseModel
{
	use hasRoles;

    protected $name = 'merge_leave';
    

}