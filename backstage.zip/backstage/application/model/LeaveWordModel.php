<?php
namespace app\model;

class LeaveWordModel extends BaseModel{
	protected $name = 'leave_word';
	
	/**
	 * 获取留言列表
	 * @param unknown $params
	 * @param string $filed
	 * @param string $orderBy
	 * @param number $page
	 * @param unknown $limit
	 * @return unknown
	 */
	public function getList($params, $filed = '*', $orderBy='id desc', $page=1, $limit = self::LIMIT)
	{
		$where= [];
		$where[] = ['status', '=', 1];
		if (!empty($params['l_type'])) {
			$where[] = ['l_type', '=', $params['l_type']];
		}
		if (!empty($params['type'])) {
			$where[] = ['type', '=', $params['type']];
		}
		if (!empty($params['c_type'])) {
			$where[] = ['c_type', '=', $params['c_type']];
		}
		if (!empty($params['author'])) {//TODO
			if ($params['author'] == -1) {//系统
				$where[] = ['author', '=', 0];
			} else {
				$where[] = ['author', '=', $params['author']];
			}
		}
		if (!empty($params['project_name'])) {
			$where[] = ['project_name', 'like', '%'.$params['project_name'].'%'];
		}
		if (!empty($params['category_1'])) {
			$where[] = ['category_1', '=', $params['category_1']];
		}
		if (!empty($params['category_2'])) {
			$where[] = ['category_2', '=', $params['category_2']];
		}
		if (!empty($params['start_time']) && !empty($params['end_time'])) {
			//$params['end_time'] = $params['end_time'].' 23:59:59';
			$where[] = ['add_time', 'between', [$params['start_time'], $params['end_time']]];
		} elseif (!empty($params['start_time']) && empty($params['end_time'])) {
			$where[] = ['add_time', '>', $params['start_time']];
		} elseif (empty($params['start_time']) && !empty($params['end_time'])) {
			//$params['end_time'] = $params['end_time'].' 23:59:59';
			$where[] = ['add_time', '<', $params['end_time']];
		}
		if (!empty($params['ip_site'])) {
			$where[] = ['ip_site', 'like', '%'.$params['ip_site'].'%'];
		}
		if (!empty($params['content'])) {
			$where[] = ['content', 'like', '%'.$params['content'].'%'];
		}
		if (!empty($params['tel'])) {
			$where[] = ['tel', '=', $params['tel']];
		}
		$leaveWordModel = $this->where($where)->field($filed)->order('add_time desc');
		$list = $leaveWordModel->paginate($limit, false, ['query' => request()->param()]);
		return $list;
	}
	
	/**
	 * 获取留言信息
	 * @param unknown $id
	 * @return multitype:number string |multitype:number unknown
	 */
	public function getInfo($id)
	{
		$info = $this->where(['id' => $id])->find();
		if (empty($info)) {
			return ['code' => 10001, 'msg' => '数据不存在'];
		}
		return ['code' => 0, 'data' => $info];
	}
	/**
	 * 编辑留言信息
	 * @param unknown $data
	 * @return multitype:string |multitype:number string
	 */
	public function updateLeave($data)
	{
		if (empty($data['id'])) {
			return ['code' => '10001', 'msg' => '数据不存在!'];
		}
		$info = $this->getInfo($data['id']);
		if (empty($info)) {
			return ['code' => '10001', 'msg' => '数据不存在!'];
		}
		$id = $data['id'];
		unset($data['id']);
		$res = $this->where(['id' => $id])->update($data);
		if ($res !== false) {
			return ['code' => 0, 'msg' => '修改成功!'];
		}
		return ['code' => 10002, 'msg' => '修改失败'];
	}
	/**
	 * 删除留言信息
	 * @param unknown $id
	 */
	public function delLeave($id)
	{
		$id = explode(';', trim($id, ';'));
		/* $info = $this->getInfo($id);
		$user = session('user');
		$roles_ids = array_column($user->roles->toArray(), 'id');
		$user_id = $user->id;
		$rolesArr = array(1 ,2);
		$is_del = true;
		if ($user->id != $info['data']['author']) {
			foreach ($rolesArr as $val) {
				if (!in_array($val, $roles_ids)) {
					$is_del = false;
				} else {
					$is_del = true;
					break;
				}
			}
		}
		if (!$is_del) {
			return ['code' => '10002', 'msg' => '删除失败'];
		}
		if (empty($info)) {
			return ['code' => '10001', 'msg' => '数据不存在!'];
		} */
		$data = [
			'status' => 0,
			'update_time' => time()
		];
		$res = $this->where([['id', 'in', $id]])->update($data);
		if ($res) {
			return ['code' => 0, 'msg' => '删除成功'];
		}
		return ['code' => 10001, 'msg' => '删除失败'];
	}
}