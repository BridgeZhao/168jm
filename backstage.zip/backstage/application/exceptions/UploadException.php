<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018/11/16 0016
 * Time: 下午 15:03
 */

namespace app\exceptions;

class UploadException extends \Exception
{

}