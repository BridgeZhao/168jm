<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018/11/13 0013
 * Time: 上午 10:49
 */
namespace app\exceptions;

class AppException extends \Exception
{

}