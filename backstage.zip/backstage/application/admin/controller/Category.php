<?php
namespace app\admin\controller;

use app\model\CategoryModel;
class Category extends Base
{
	function getList()
	{
		$params = $this->request->param();
		$pid = !empty($params['pid'])?$params['pid']:0;
		$categoryModel = new CategoryModel();
		$list = $categoryModel->getCategory($pid);
		return $list;
	}
}