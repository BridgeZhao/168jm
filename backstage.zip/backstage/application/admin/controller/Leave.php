<?php
namespace app\admin\controller;

use app\model\LeaveWordModel;
use app\model\CategoryModel;
use app\model\UserModel;
use app\model\distributionModel;
use think\Db;
use think\facade\Config;
use app\model\MergeLeaveModel;
use think\Loader;

class Leave extends Base
{
	//public $request;
	
	/* public function __construct()
	{
		//$this->request = new Request();
	} */
	/**
	 * 留言列表
	 * @return Ambigous <\app\traits\mixed, string, mixed>
	 */
	public function index()
	{
		$leaveWordModel = new LeaveWordModel();
		$categoryModel = new CategoryModel();
		$where = [];
		$params = $this->request->param();
		$this->list = $leaveWordModel->getList($params);
		$params['category_1'] = !empty($params['category_1'])?$params['category_1']:0;
		$params['category_2'] = !empty($params['category_2'])?$params['category_2']:0;
		$this->assign('params', $params);
		//获取行业
		$categoryAll = $categoryModel->getCategoryList();
		$categoryAllList = $cList = [];
		foreach ($categoryAll as $val) {
			$cList[$val['id']] = $val;
			if ($val['pid'] == 0) {
				$categoryAllList[$val['id']] = array(
						'id' => $val['id'],
						'title' => $val['title'],
						'pid' => $val['pid'],
				);
			}
		}
		foreach ($categoryAll as $val) {
			if ($val['pid'] != 0) {
				$categoryAllList[$val['pid']]['item'][] = array(
						'id' => $val['id'],
						'title' => $val['title'],
						'pid' => $val['pid'],
				);
			}
		}
		
		$this->assign('cList', $cList);
		$this->assign('categoryAllList', $categoryAllList);
		//获取用户
		$userModel = new UserModel();
		$userList = $userModel->getAll();
		$userList = changeArrayKey($userList, 'id');
		$this->assign('userList', $userList);
		return $this->fetch();
	}
	
	public function edit()
	{
		$id = $this->request->param()['id'];
		$leaveWordModel = new LeaveWordModel();
		if ($this->request->isPost()) {
			$params = $this->request->param();
			$data = [
				'project_name' => $params['project_name'],
				'name' => $params['name'],
				'tel' => $params['tel'],
				'sex' => !empty($params['sex'])?$params['sex']:1,
				'invest_money' => $params['invest_money'],
				'ip_site' => $params['ip_site'],
				'content' => $params['content'],
				'id' => $params['id'],
				'update_time' => time(),
			];
			$result =$leaveWordModel->updateLeave($data);
			if ($result['code'] == 0) {
				return $this->success($result['msg'], $params['referer']);
			}
			return $this->error($result['msg']);
		}
		$data = $leaveWordModel->getInfo($id);
		if ($data['code'] != 0) {
			return $this->fetch('/message',['code' => '数据不存在','msg' => '数据不存在','url' => '/admin/leave/index','wait' => 3]);
		}
		$investMoneyArr = [
			'1' => '1万以下',
			'2' => '1-3万',
			'3' => '3-5万',
			'4' => '5-10万',
			'5' => '10-20万',
			'6' => '20-50万',
			'7' => '50-100万',
			'8' => '100万以上',
		];
		$this->assign('info', $data['data']);
		$this->assign('investMoneyArr', $investMoneyArr);
		$this->assign('historyUrl', $_SERVER['HTTP_REFERER']);
		return $this->fetch();
	}
	public function delete()
	{
		$params = $this->request->param();
		$leaveWordModel = new LeaveWordModel();
		$res = $leaveWordModel->delLeave($params['id']);
		if ($res['code'] == 0) {
			if (!empty($params['ajax'])) {//判断是否是ajax提交
				$res['url'] = $_SERVER['HTTP_REFERER'];
				return $res;
			}
			return $this->success('删除成功', $_SERVER['HTTP_REFERER']);
		}
		return $this->error($res['msg']);
	}
	
	/**
	 * 留言分配/取消分配
	 */
	public function distribution()
	{
		$params = $this->request->param();
		if (empty($params['l_id']) || empty($params['user_id'])) {
			return false;
		}
		$distributionModel = new distributionModel();
		$res = $distributionModel ->distribution($params['l_id'], $params['user_id'], $params['status']);
		return $res;
	}
	/**
	 * 获取留言分配用户
	 */
	public function getDistributionUser()
	{
		$distributionModel = new distributionModel();
		$params = $this->request->param();
		$l_id = $params['id'];
		$keyword = !empty($params['name'])?$params['name']:'';
		$list= $distributionModel->getDistributionUser($l_id, $keyword);
		
		return array('code' => 0, 'data' => $list);
	}
	
	/**
	 * 留言录入列表
	 */
	public function entryList()
	{
		//获取用户session
		$user = $this->request->session('user');
		$user_id = $user->id;
		$roles_id = $user->roles[0]->id;
		
		$leaveWordModel = new LeaveWordModel();
		$categoryModel = new CategoryModel();
		$userModel = new UserModel();
		$where = [];
		$params = $this->request->param();
		$params['l_type'] = 1;
		if (!in_array($roles_id, array(1, 2))) {
			$params['author'] = $user_id;
		}
		$list = $leaveWordModel->getList($params);
		$params['category_1'] = !empty($params['category_1'])?$params['category_1']:0;
		$params['category_2'] = !empty($params['category_2'])?$params['category_2']:0;
		//获取用户数据
		$userList = $userModel->getAll();
		$userList = changeArrayKey($userList, 'id');
		$this->assign('params', $params);
		$categoryAll = $categoryModel->getCategoryList();
		$categoryAllList = $cList = [];
		foreach ($categoryAll as $val) {
			$cList[$val['id']] = $val;
			if ($val['pid'] == 0) {
				$categoryAllList[$val['id']] = array(
					'id' => $val['id'],
					'title' => $val['title'],
					'pid' => $val['pid'],
				);
			}
		}
		foreach ($categoryAll as $val) {
			if ($val['pid'] != 0) {
				$categoryAllList[$val['pid']]['item'][] = array(
					'id' => $val['id'],
					'title' => $val['title'],
					'pid' => $val['pid'],
				);
			}
		}
		$this->assign('cList', $cList);
		$this->assign('categoryAllList', $categoryAllList);
		$this->assign('list', $list);
		$this->assign('userList', $userList);
		
		$investMoneyArr = [
			'1' => '1万以下',
			'2' => '1-3万',
			'3' => '3-5万',
			'4' => '5-10万',
			'5' => '10-20万',
			'6' => '20-50万',
			'7' => '50-100万',
			'8' => '100万以上',
		];
		$this->assign('investMoneyArr', $investMoneyArr);
		$userModel = new UserModel();
		return $this->fetch();
	}
	
	/**
	 * 新增客户录入
	 * @return Ambigous <\app\traits\mixed, string, mixed>
	 */
	public function addEntry()
	{
		if ($_POST) {
			$leaveWordModel = new LeaveWordModel();
			$params = $this->request->param();
			$user = $this->request->session('user');
			$tel = !empty($params['tel'])?$params['tel']:'';
			$info = $leaveWordModel->where(['tel' => $tel, 'status' => 1])->find();
			if (!empty($info)) {
				$this->error('电话号码已存在');
			}
			$data = array(
				'name' => !empty($params['name'])?$params['name']:'',
				'tel' => !empty($params['tel'])?$params['tel']:'',
				'ip_site' => !empty($params['ip_site'])?$params['ip_site']:'',
				'c_type' => !empty($params['c_type'])?$params['c_type']:1,
				'sex' => !empty($params['sex'])?$params['sex']:1,
				'project_name' => !empty($params['project_name'])?$params['project_name']:'',
				'invest_money' => !empty($params['invest_money'])?$params['invest_money']:'',
				'content' => !empty($params['content'])?$params['content']:'',
				'author' => $user->id,
				'add_time' => date("Y-m-d H:i:s"),
				'category_1' => !empty($params['category_1'])?$params['category_1']:0,
				'category_2' => !empty($params['category_2'])?$params['category_2']:0,
			);
			$res = $leaveWordModel->save($data);
			if ($res !== false) {
				$this->success('添加成功', url('leave/entrylist'));
			} else {
				$this->error('添加失败');
			}
		}
		$categoryModel = new CategoryModel();
		$categoryAll = $categoryModel->getCategoryList();
		$categoryList = array();
		foreach ($categoryAll as $val) {
			$cList[$val['id']] = $val;
			if ($val['pid'] == 0) {
				$categoryList[$val['id']] = array(
						'id' => $val['id'],
						'title' => $val['title'],
						'pid' => $val['pid'],
				);
			}
		}
		foreach ($categoryAll as $val) {
			if ($val['pid'] != 0) {
				$categoryList[$val['pid']]['item'][] = array(
						'id' => $val['id'],
						'title' => $val['title'],
						'pid' => $val['pid'],
				);
			}
		}
		//投资金额
		$investMoneyArr = [
			'1' => '1万以下',
			'2' => '1-3万',
			'3' => '3-5万',
			'4' => '5-10万',
			'5' => '10-20万',
			'6' => '20-50万',
			'7' => '50-100万',
			'8' => '100万以上',
		];
		$this->assign('investMoneyArr', $investMoneyArr);
		$this->assign('categoryList', $categoryList);
		$this->assign('url', url('leave/addEntry'));
		return $this->fetch();
	}
	/**
	 * 编辑客户录入
	 * @return void|Ambigous <\app\traits\mixed, string, mixed>
	 */
	public function editEntry()
	{
		$leaveWordModel = new LeaveWordModel();
		if ($this->request->isPost()) {
			$params = $this->request->param();
			$tel = !empty($params['tel'])?$params['tel']:'';
			$id = $params['id'];
			$info = $leaveWordModel->where([['tel', 'eq', $tel], ['id', 'neq', $id],['status', 'eq', 1]])->find();
			if (!empty($info)) {
				$this->error('电话号码已存在');
			}
			$data = array(
				'name' => !empty($params['name'])?$params['name']:'',
				'tel' => !empty($params['tel'])?$params['tel']:'',
				'ip_site' => !empty($params['ip_site'])?$params['ip_site']:'',
				'c_type' => !empty($params['c_type'])?$params['c_type']:1,
				'sex' => !empty($params['sex'])?$params['sex']:1,
				'project_name' => !empty($params['project_name'])?$params['project_name']:'',
				'invest_money' => !empty($params['invest_money'])?$params['invest_money']:0,
				'content' => !empty($params['content'])?$params['content']:'',
				'id' => $params['id'],
				'category_1' => !empty($params['category_1'])?$params['category_1']:0,
				'category_2' => !empty($params['category_2'])?$params['category_2']:0,
			);
			$res = $leaveWordModel->updateLeave($data);
			if ($res['code'] == 0) {
				return $this->success($res['msg'], url('leave/entryList'));
			}
			return $this->error($res['msg']);
		}
		//投资金额
		$investMoneyArr = [
			'1' => '1万以下',
			'2' => '1-3万',
			'3' => '3-5万',
			'4' => '5-10万',
			'5' => '10-20万',
			'6' => '20-50万',
			'7' => '50-100万',
			'8' => '100万以上',
		];
		//行业
		$categoryModel = new CategoryModel();
		$categoryAll = $categoryModel->getCategoryList();
		$categoryList = array();
		foreach ($categoryAll as $val) {
			if ($val['pid'] == 0) {
				$categoryList[$val['id']] = array(
						'id' => $val['id'],
						'title' => $val['title'],
						'pid' => $val['pid'],
				);
			}
		}
		foreach ($categoryAll as $val) {
			if ($val['pid'] != 0) {
				$categoryList[$val['pid']]['item'][] = array(
						'id' => $val['id'],
						'title' => $val['title'],
						'pid' => $val['pid'],
				);
			}
		}
		
		$this->assign('investMoneyArr', $investMoneyArr);
		$id = $this->request->param()['id'];
		$info = $leaveWordModel->getInfo($id);
		$this->assign('info', $info['data']);
		$this->assign('url', url('leave/editEntry'));
		$this->assign('categoryList', $categoryList);
		return $this->fetch('add_entry');
	}
	/**
	 * 删除客户录入
	 */
	public function delEntry()
	{
		$params = $this->request->param();
		$leaveWordModel = new LeaveWordModel();
		$res = $leaveWordModel->delLeave($params['id']);
		if ($res['code'] == 0) {
			$this->success('删除成功', url('leave/entryList'));
		}
		return $this->error($res['msg']);
	}
	
	/**
	 * 客户数据列表
	 * @return Ambigous <\app\traits\mixed, string, mixed>
	 */
	public function customerList()
	{
		$params = $this->request->param();
		$user = $this->request->session('user');
		$user_id = $this->userId;
		$distributionModel = new distributionModel();
		$list = $distributionModel->customerList($user_id, $params);
		$this->assign('list', $list);
		$this->assign('userName', $user->name);
		return $this->fetch();
	}
	
	/**
	 * 客户数据反馈
	 */
	public function customerFeedback()
	{
		$params = $this->request->param();
		if (empty($params['id']) || empty($params['d_id']) || (empty($params['type']) && empty($params['content']))) {
			return array('code' => 10003, 'data' => array('msg' => '参数不正确'));
		}
		$id = $params['id'];
		$d_id = $params['d_id'];
		$type = !empty($params['type'])?$params['type']:'';
		$content = !empty($params['content'])?$params['content']:'';
		$distributionModel = new distributionModel();
		$res = $distributionModel->feedback($id, $d_id, $type, $content);
		return $res;
	}
	
	/**
	 * 反馈列表
	 */
	public function feedbackList()
	{
		$params = $this->request->param();
		$user = $this->request->session('user');
		$distributionModel = new distributionModel();
		$list = $distributionModel->feedbackList($params);
		$this->assign('list', $list);
		$this->assign('userName', $user->name);
		return $this->fetch();
	}
	
	/**
	 * 合并留言
	 */
	public function mergeLeave()
	{
		//查询上次同步数据位置
		$merge_leave = new MergeLeaveModel();
		$m_data = $merge_leave->find();
		$leave_id = !empty($m_data)?$m_data['join_leave_id']:0;
		$where = array();
		if (!empty($leave_id)) {
			$where[] = array('id', '>', $leave_id);
		}
		//切换数据库
		$table = Config::get('table.join');
    	$db = Db::connect($table);
    	//获取上次同步数据之后的数据
    	$on_leave_word = $db->name('leave_word')->where($where)->group('tel')->select();
    	$leave_word_end_id = end($on_leave_word)['id'];
    	$data = [];
    	foreach ($on_leave_word as $val) {
    		$data[] = [
    			'project_id' => $val['project_id'],
    			'ip' => $val['ip'],
    			'invest_money' => $val['invest_money'],
    			'name' => $val['name'],
    			'sex' => $val['sex'],
    			'tel' => $val['tel'],
    			'content' => $val['content'],
    			'category_1' => $val['category_1'],
    			'category_2' => $val['category_2'],
    			'winxin_number' => $val['winxin_number'],
    			'is_show' => $val['is_show'],
    			'ip_site' => $val['ip_site'],
    			'add_time' => $val['add_time'],
    			'project_name' => $val['project_name'],
    			'is_red' => $val['is_red'],
    			'type' => $val['type'],
    			'c_type' => $val['c_type'],
    			'author' => 0,
    			'status' => 1,
    			'l_type' => 2,
    			'update_time' => time(),
			];
    	}
    	//切换到当前项目数据库
    	$db2 = Db::connect();
    	//同步留言数据
    	$db2->name('leave_word')->insertAll($data);
    	$insertData = array(
    		'join_leave_id' => $leave_word_end_id
    	);
    	$db2 = Db::connect();
    	//跟新同步数据位置
    	if (!empty($leave_id) && !empty($data)) {
    		$m_where = array('id' => $m_data['id']);
    		$insertData = array(
    			'join_leave_id' => $leave_word_end_id,
    			'id' => $m_data['id'],
    		);
    		$db2->name('merge_leave')->update($insertData);
    	} elseif (!empty($data)) {
    		$merge_leave->insert($insertData);
    	}
	}
	
	/**
	 * 合并分类
	 */
	public function mergeCategory()
	{
		$categoryModel = new CategoryModel();
		$categoryInfo = $categoryModel->order('id desc')->find();
		$categoryId = $categoryInfo['id'];
		$table = Config::get('table.join');
		$db = Db::connect($table);
		$categoryList = $db->name('category')->field('id,name,title,pid')->where([['id', '>', $categoryId]])->select();
		$db2 = Db::connect();
		$db2->name('category')->insertAll($categoryList);
	}
	
	/**
	 * 导出客户数据
	 */
	public function exportCustomer()
	{
		$params = $this->request->param();
		$user_id = $this->userId;
		$ids = array();
		if (!empty($params['id'])) {
			$ids = explode(';', trim($params['id'], ';'));
		}
		$distributionModel = new distributionModel();
		$params['id'] = $ids;
		$list = $distributionModel->customerList($user_id, $params, 0);
		$exportData = array();
		$did = array();
		foreach ($list as $val) {
			$did[] = $val['did'];
			$exportData[] = array(
				'project_name' => $val['project_name'],
				'name' => $val['name'],
				'tel' => $val['tel'],
				'sex' => $val['sex']==1?'男':'女',
				'ip_site' => $val['ip_site'],
				'add_time' => $val['add_time'],
				'content' => $val['content'],
			);
		}
		$where[] = array('id', 'in', $did);
		$update = array(
				'is_export' => 1,
				'export_time' => time(),
		);
		$distributionModel->where($where)->update($update);
		
		$head = array(
			array('project_name', '项目名称'),
			array('name', '姓名'),
			array('tel', '联系电话'),
			array('sex', '性别'),
			array('ip_site', '地址'),
			array('add_time', '留言时间'),
			array('content', '留言内容')
		);
		$xlsName = '客户数据';
		$this->exportExcel($xlsName,$head,$exportData);
	}
	
	/**
	 * 
	 * @param unknown $expTitle
	 * @param unknown $expCellName
	 * @param unknown $expTableData
	 */
	public function exportExcel($expTitle,$expCellName,$expTableData){
		$xlsTitle = iconv('utf-8', 'gb2312', $expTitle);//文件名称
	
		$fileName =$xlsTitle . date('_YmdHis');//or $xlsTitle 文件名称可根据自己情况设定
		$cellNum = count($expCellName);
		$dataNum = count($expTableData);
	
		$objPHPExcel = new \PHPExcel();
		$cellName = array('A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z','AA','AB','AC','AD','AE','AF','AG','AH','AI','AJ','AK','AL','AM','AN','AO','AP','AQ','AR','AS','AT','AU','AV','AW','AX','AY','AZ');
	
		//$objPHPExcel->getActiveSheet(0)->mergeCells('A1:'.$cellName[$cellNum-1].'1');//合并单元格
		// $objPHPExcel->setActiveSheetIndex(0)->setCellValue('A1', $expTitle.'  Export time:'.date('Y-m-d H:i:s'));
		for($i=0;$i<$cellNum;$i++){
			$objPHPExcel->setActiveSheetIndex(0)->setCellValue($cellName[$i].'1', $expCellName[$i][1]);
		}
		// Miscellaneous glyphs, UTF-8
		for($i=0;$i<$dataNum;$i++){
			for($j=0;$j<$cellNum;$j++){
				$objPHPExcel->getActiveSheet(0)->setCellValue($cellName[$j].($i+2), $expTableData[$i][$expCellName[$j][0]]);
			}
		}
	
		header('pragma:public');
		header('Content-type:application/vnd.ms-excel;charset=utf-8;name="'.$xlsTitle.'.xls"');
		header("Content-Disposition:attachment;filename=$fileName.xls");//attachment新窗口打印inline本窗口打印
		$objWriter = \PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel5');
		$objWriter->save('php://output');
		exit;
	}
	
	public function customerTrend()
	{
		$start_time = strtotime(date("Y-m-d", strtotime("-6 days")));
		$end_time = strtotime('+7 days', $start_time)-1;
		$distributionModel = new distributionModel();
		$listAll = $distributionModel->customerTrend($start_time, $end_time);
		$data = $list = [];
		foreach ($listAll as $val) {
			$list[$val['add_date']] = $val['total'];
		}
		for ($i=0; $i<7; $i++) {
			$date_time = date("Y-m-d", strtotime('+'.$i.' days', $start_time));
			$data[] = [
				'add_time' => $date_time,
				'total' => !empty($list[$date_time])?$list[$date_time]:0,
			];
		}
		$this->assign('data', $data);
		$this->display();
	}
}