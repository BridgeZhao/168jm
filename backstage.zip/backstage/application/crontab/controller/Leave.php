<?php
namespace app\crontab\controller;
use think\Controller;
use think\Db;
use think\Log;
use think\Model;
use think\facade\Config;

class Leave extends Controller{
	/**
	 * 留言定时任务
	 */
	public function index()
	{
		$mergeInfo = Db::name('merge_leave')->find();
		$leave_id = !empty($mergeInfo)?$mergeInfo['join_leave_id']:0;
		$where = array();
		if (!empty($leave_id)) {
			$where[] = array('id', '>', $leave_id);
		}
		$table = Config::get('table.join');
		$db = Db::connect($table);
		$on_leave_word = $db->name('leave_word')->where($where)->select();
		$leave_word_end_id = end($on_leave_word)['id'];
		
		$data = [];
		foreach ($on_leave_word as $val) {
			$data[] = [
			'project_id' => $val['project_id'],
			'ip' => $val['ip'],
			'invest_money' => $val['invest_money'],
			'name' => $val['name'],
			'sex' => $val['sex'],
			'tel' => $val['tel'],
			'content' => $val['content'],
			'category_1' => $val['category_1'],
			'category_2' => $val['category_2'],
			'winxin_number' => $val['winxin_number'],
			'is_show' => $val['is_show'],
			'ip_site' => $val['ip_site'],
			'add_time' => $val['add_time'],
			'project_name' => $val['project_name'],
			'is_red' => $val['is_red'],
			'type' => $val['type'],
			'c_type' => $val['c_type'],
			'author' => 0,
			'status' => 1,
			'l_type' => 2,
			'update_time' => time(),
			];
		}
		$db2 = Db::connect();
		$db3 = clone $db2;
		$db2->name('leave_word')->insertAll($data);
		$insertData = array(
				'join_leave_id' => $leave_word_end_id
		);
		if (!empty($leave_id) && !empty($data)) {
			$m_where = array('id' => $mergeInfo['id']);
			$insertData = array(
					'join_leave_id' => $leave_word_end_id,
					'id' => $mergeInfo['id'],
			);
			$db3->name('merge_leave')->update($insertData);
		} elseif (!empty($data)) {
			$db3->name('merge_leave')->insert($insertData);
		}
		echo '同步完成';
	}
}
