<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018/11/16 0016
 * Time: 下午 14:50
 */
namespace app\component\upload;

interface UploadInterface
{
	public function file();

	public function image();
}