<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2019/1/30
 * Time: 16:32
 */
namespace thinking\icloud\auth;

use thinking\icloud\Utility;

final class OssAuth
{
    use Utility;


}