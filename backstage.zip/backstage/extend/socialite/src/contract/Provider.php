<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018/12/28
 * Time: 11:36
 */
namespace thinking\socialite\contract;

interface Provider
{

    public function user();
}